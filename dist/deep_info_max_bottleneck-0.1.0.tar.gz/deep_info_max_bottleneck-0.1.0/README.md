# Deep Info Max Bottleneck

A brief description of your package, its purpose, and functionalities.

## Installation

```bash
pip install deep_info_max_bottleneck
